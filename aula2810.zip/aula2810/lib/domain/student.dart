class Student {
  int? id;
  String? rm;
  String? name;
  int? age;

  Student({this.id, this.rm, this.name, this.age});

  Student.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    rm = json['rm'];
    name = json['name'];
    age = json['age'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['rm'] = rm;
    data['name'] = name;
    data['age'] = age;
    return data;
  }

  @override
  String toString() {
    return 'Student{id: $id, rm: $rm, name: $name, age: $age}';
  }



}