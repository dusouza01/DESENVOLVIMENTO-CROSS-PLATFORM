package com.example.aula2810

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
