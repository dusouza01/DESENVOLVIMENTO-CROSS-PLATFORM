void main (List<String>args){
//Aritméticos
int a =7;
int b = 3;

int resultado = a + b;

print(resultado);
print(a-b);
print(a*b);
print(a/b);
print(a%b);




// Operadores Lógicos
bool ehFragil = true;
bool ehCaro = false;
print(ehFragil & ehCaro);
print(ehFragil | ehCaro);
print(ehFragil ^ ehCaro);
print(!ehFragil);
print(!!ehFragil);

}