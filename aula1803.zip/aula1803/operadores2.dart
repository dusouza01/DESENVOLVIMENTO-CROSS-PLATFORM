void main(List<String> args) {
  
  int a = 3;
  int b = 4;

  a++;
  --a;

  print(a);
  print(a++ == --b);
  
}